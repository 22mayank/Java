import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;
public class FileOperation 
{
public void readFile() 
{
Scanner sc = new Scanner(System.in);
String fileName;
System.out.print("Enter the text file name that you want to read from the D:\\ drive: "); fileName = sc.nextLine();
try (BufferedReader br = new BufferedReader(new FileReader("D:\\" + fileName + ".txt "))) 
{
String s;
System.out.println("\nThe " + fileName + " contains the following text:\n");

while ((s = br.readLine()) != null)
	{
System.out.println(s);
}
}
 catch (Exception e)
 {
System.out.println("File does not exists."); menu();
}
}
public void writeFile() 
{
Scanner sc = new Scanner(System.in);
String fileName, text;
System.out.print("Enter the file name from the D:\\ drive in which you 'want to write: "); fileName = sc.nextLine ();
System.out.print("Enter the text you want to write in the " + fileName + " file: "); text = sc.nextLine();
try 
{
FileWriter fos = new FileWriter("D:\\" + fileName + ".txt", true);
BufferedWriter bw = new BufferedWriter(fos); bw.newLine(); bw.write(text);
bw.close (); fos.close();
System.out.println("\nThe text has been added in the file");
}
 catch (Exception e)
 {
System.out.println("File does not exists"); menu();
}
}
public void searchFileO()
 {
Scanner sc = new Scanner(System.in);
String fileName, text; int counter = 0, flag = 0;
System.out.print("Enter the file name from the D:\\ drive in which you want to search: ");
fileName = sc.nextLine();
System.out.print("Enter the string you want to search in the " + fileName + " file: "); text = sc.nextLine();
try (BufferedReader br =new BufferedReader(new FileReader("D:\\" + fileName + ".txt "))) 
	{
String s;
while ((s = br.readLine()) != null) 
{
String splitData()=s.split(" ");
{
for (int i = 0; i < splitData.length; i++) 
{
	if (splitData(i).equals(text))
	{
if (splitData(i).equals(text)) 
{
counter++; flag = 1;
}
}
}
	}}} 
catch (Exception e) 
{
System.out.println("File does not exits"); menu () ;
}
if (flag==1)
	{
	
if (counter==1)
	{
System.out.println("\"" + text + "\" has occured " + counter + " time");
} else {
System.out.println("\"" + text + "\" has occured " + counter + " times");
}
} else {
System.out.println("The entered word doest not exist in the file.");
}
 }

 public void menu() 
{
	int option;
Scanner sc = new Scanner(System.in);
System.out.println (" \n-----Menu---------") ;
System.out.println("1. Reading");
System.out.println("2. Writing");
System.out.println("3. Searching");
System.out.println("4. Exit");
System.out.print("\nChoose the option: ");
option = sc.nextInt();
switch (option) 
{
	case 1:readFile(); menu(); break;
	case 2:writeFile(); menu(); break;
	case 3:searchFile();menu(); break; 
	case 4:System.exit(0); break;
	default:System.out.println("Incorrect menu option");
menu(); break;
}
}
public static void main(String args[])
{
FileOperation fo = new FileOperation();
fo.menu();
}
}