class SelectionException extends Exception
{
SelectionException()
{
System.out.println("You are not allowed");

}
}

import java.util.Scanner;
public class NewAxis1
{
String name,contactno;
int age;
Scanner details=new Scanner(System.in);
static void showage(int mage)throws SelectionException
{
if ((mage<18)||(mage>55))
{
throw new SelectionException();
}

}
public void form()
{
System.out.println("Disco Registration Form");
System.out.println("Enter the name:");
name=details.nextLine();
System.out.println("Enter the contact number:");
contactno=details.nextLine();
System.out.println("Enter the age:");
age=details.nextInt();
try
{
showage(age);
}
catch(SelectionException obja)
{

}
}
public static void main(String[] args)
{
NewAxis1 obj1=new NewAxis1();
obj1.form();

}
}