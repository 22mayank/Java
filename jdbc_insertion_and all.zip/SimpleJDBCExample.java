import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class SimpleJDBCExample
{
public static void main(String args[])throws Exception
Connection con=null;
String url="jdbc:mysql://localhost:3306/mysql?zeroDateTimeBehavior=convertToNull";
String username="root";
String password="";
String query="SELECT*FROM employee";
try
{
Class.forName("com.mysql.jdbc.Driver");
con=DriverManager.getConnection("url","root","");
Statement st=con.createStatement();
ResultSet rs=st.executeQuery(query);
System.out.println("\tempname\tid\tage");
while(rs.next())
{
String emname=rs.getString("empname");
int empid=rs.getInt("id");
imt empage=rs.getInt("age");
System.out.println("\t"+emname+"\t"+empid+"\t"+empage);



}
}
catch(SQLException e)
{
System.out.println("SQLException"+e);
}
}
}