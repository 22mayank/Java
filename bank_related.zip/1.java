/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package HaV0k;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.LinkedList;
import java.util.Scanner;

public class SavingAccount {
String s;

public void showMenu() {
Scanner sc = new Scanner(System.in);
int input;

System.out.println("\n----Menu----");
System.out.println("1. Open a new account");
System.out.println("2. Deposit money");
System.out.println("3. Withdraw money");
System.out.println("4. Check balance");
System.out.println("5. Exit");
System.out.println("Enter your choice: ");
input = sc.nextInt();

switch (input) {

case 1:{
openAccount();
showMenu();
break;}

case 2:{
deposit();
showMenu();
break;}

case 3:{
withdraw();
showMenu();
break;}

case 4:{
cthal();
showMenu();
break;}
case 5:{
System.exit(0);
break;}
default:
System.out.println("Invalid choice");
showMenu();
break;

}

public void openAccount() {
Scanner sc = new Scanner(System.in);
String name, contact, address, t = null;
int amount, acnum = 0;
LinkedList ll = new LinkedList();

System.out.print("Enter the name: ");

name = sc.next();
System.out.print("\nEnter contact no: ");
contact = sc.next();
System.out.print("\nEnter address: ");
address = sc.next();

System.out.print("\nEnter initial amount: ");
amount = sc.nextInt();

try (BufferedReader br = new BufferedReader(new FileReader("Saving_Account.txt "))) {

while ((s = br.readLine()) != null) {
ll.add(s);
t = ll.aetLast().toStrina();

if (t != null) {
String splitData[] = t.split(",");
acnum = Integer.parseInt(splitData[0]);

acnum += 1;
} else {
acnum += 1;
}
try (FileWriter fos = new FileWriter
("Saving_Account.txt ", true)) {
BufferedWriter bw = new BufferedWriter

(fos);

bw.write(acnum + "," + name + "," + contact
+ "," + address + "," + amount);

bw.newLine();

bw.close();

fos.close();

System.out.println
("��") ;

System.out.println("Congratulations! Your account has been created.");

System.out.println("Following are the details:");

System.out.println("Account Number: " +
acnum);

System.out.println("Account Holder: " +
name);

System.out.println("Contact Number: " +
contact);

System.out.println("Address: " + address);

System.out.println("Balance Amount: $" +
amount);

try (FileWriter fw = new FileWriter(acnum +
".txt ", true)) {

BufferedWriter bfw = new BufferedWriter(fw);
bfw.write("Balance: " + amount);

bfw.newLine();
bfw.close();
fw.close();

} catch (Exception e) {

}

} catch (Exception e) {
System.out.println(e);

}

} catch (Exception e) {

System.out.println(e);

}

public void deposit() {
Scanner sc = new Scanner(System.in);

int anum, credit = 0, bal = 0, flag = 0;

System.out.println("Enter account number: ");
anum = sc.nextInt();

try (BufferedReader hr = new BufferedReader(new
FileReader("Saving_Account.txt "))) {

while ((5 = br.readLine()) != null) {
String splitData[] = s.split(",");
int temp = Integer.parseInt(splitData[0]);

if (anum == temp) {
flag = 1;
}
}
} catch (Exception e) {

}
if (flag == 1) {

trv (RIIFFeredReader hr�l = new Buffered'Reader

(new FileReader(anum + ".txt "))) {
System.out.println("Enter the amount: ");
credit = sc.nextInt();

if (credit <= 0) {
System.out.println("Deposit amount
cannot zero or less than zero");
showMenu();

}

while ((5 = br1.readLine()) != null) {
String splitData1[] = s.split(" ");

if (splitData1[0].equals("Balance:")) {
bal = Integer.parseInt(splitDatal
[1].toString());

bal += credit;

}

} catch (Exception e) {
}

try (FileWriter fw = new FileWriter(anum +
".txt ", true)) {

BufferedWriter bfw = new BufferedWriter
(fw);
bfw.write("Credited: " + credit);
bfw.newLine();
bfw.write ("=") ;
bfw.newLine();
bfw.write("Balance: " + bal);
bfw.newLine();
bfw.close();
fw.close();
System.out.println("II");

System.out.println("3" + credit + " has been credited. Now, your new balance is: S" + bal);
System.out.println("II");

} catch (Exception e) {
}

} else {
System.out.println("Invalid account number");
showMenu();

}

public void withdraw() {
Scanner 5c = new Scanner(System.in);
int anum, debit = 0, bal = 0, flag = 0;

System.out.println("Enter account number: ");
anum = sc.nextInt();

try (BufferedReader br = new BufferedReader(new
FileReader("Saving_Account.txt "))) {

while ((5 = br.readLine()) != null) {
String splitData[] = s.split(",");
int temp = Integer.parseInt(splitData[0]);

if (anum == temp) {
flag = 1;
}
}

} catch (Exception e) {

}
if (flag == 1) {

try (BufferedReader brl = new BufferedReader
(new FileReader(anum + ".txt "))) {

//�_g�-�-"���-�r��---�-'\ ��--�� ---� �"��--- a I

debit = sc.nextInt();

if (debit <= 0) {
System.out.println("Invalid amount.Please enter proper amount");
showMenu();

}

while ((s = br1.readLine()) != null) {
String splitData1[] = s.split(" ");

if (splitDatal[0].equals("Balance:")) {
bal = Integer.parseInt(splitDatal[1].toString());

}
}
if (bal < debit) {
System.out.println("The account balance is low. You cannot withdraw this amount. Please enter less amount");
showMenu();
} else {
bal -= debit;
}
} catch (Exception e) {
}
try (FileWriter fw = new FileWriter(anum +
".txt ", true)) {
BufferedWriter bfw = new BufferedWriter
(fw);
bfw.write("Debited: " + debit);
bfw.newLine();
bfw.write ("=") ;
bfw.newLine();
bfw.write("Balance: " + bal);

bfw.newLine();
bfw.close();

bfw.close();

fw.close();
System.out.println("II");

System.out.println("$ " + debit + " has been debited. Now, your new balance is: $ " + bal);
System.out.println("II");
} catch (Exception e) {
}

} else {
System.out.println("Invalid account number");
showMenu();

}}

public void cthal() {
Scanner 5c = new Scanner(System.in);
int anum, bal = 0, flag = 0;

System.out.println("Enter account number: ");
anum = sc.nextInt();

try (BufferedReader br = new BufferedReader(new
FileReader("Saving_Account.txt "))) {

while ((5 = br.readLine()) != null) {
String splitData[] = s.split(",");
int temp = Integer.parseInt(splitData[0]);

if (anum == temp) {
flag = 1;
}
}
} catch (Exception e) {

1

} catch (Exception e) {

}
if (flag == 1) {

try (BufferedReader brl = new BufferedReader
(new FileReader(anum + ".txt "))) {

while ((5 = br1.readLine()) != null) {
String splitData1[] = s.split(" ");

if (splitData1[0].equals("Balance:")) {
bal = Integer.parseInt(splitDatal
[1].toString());

}

}
} catch (Exception e) {

System.out.println("Account does not exist");
cthal();

System.out.println("II");
System.out.println("Your current balance is: S"
+ bal);
System.out.println("II");
} 
else {
System.out.println("Invalid account number");
showMenu();

}

//public static void main(String[] args) {

public static void main (String[] args) {
SavingAccount acc = new SavingAccount () ;
acc . showMenu () ;



}}